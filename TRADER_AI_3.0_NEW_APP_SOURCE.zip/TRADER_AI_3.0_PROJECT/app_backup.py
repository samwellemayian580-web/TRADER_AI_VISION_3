
from flask import Flask, request, jsonify, render_template_string
from risk.risk_manager import RiskManager
from analysis.market_analyzer import MarketAnalyzer

app = Flask(__name__)
RISK_MANAGER = RiskManager(equity=10.0)
ANALYZER = MarketAnalyzer()

BOT = {
    "name": "TRADER AI 2.0",
    "symbol": "XAUUSD",
    "status": "STOPPED",
    "mode": "SIMULATION",
    "execution": "MANUAL",
    "strategy": "SCALPING",
    "risk": 1.0,
    "decision": "WAITING FOR MARKET DATA"
}

PAGE = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TRADER AI 2.0</title>
<style>
body {
    background:#10151d; color:white; font-family:Arial;
    max-width:500px; margin:auto; padding:20px;
}
h1 {color:#e8b84b;}
.card {
    background:#1c2633; padding:18px;
    border-radius:12px; margin:15px 0;
}
button,select {
    width:100%; padding:14px; margin-top:10px;
    border:0; border-radius:8px; font-size:16px;
}
.start {background:#168b5a;color:white;}
.stop {background:#b83b45;color:white;}
small {color:#aab6c5;}
</style>
</head>
<body>

<h1>TRADER AI 2.0</h1>
<small>XAUUSD MARKET INTELLIGENCE</small>

<div class="card">
<h3>System status</h3>
<h2 id="status">STOPPED</h2>
<p>Instrument: XAUUSD</p>
<p>Environment: SIMULATION ONLY</p>
<p>Risk per trade: <span id="risk">1</span>%</p>
</div>

<div class="card">
<h3>Trading strategy</h3>
<select id="strategy">
<option value="SCALPING">Scalping</option>
<option value="SWING">12–24 Hour Analysis</option>
</select>

<h3>Execution mode</h3>
<select id="execution">
<option value="MANUAL">Manual approval</option>
<option value="AUTO">Automatic simulation</option>
</select>

<button onclick="saveSettings()">SAVE SETTINGS</button>
</div>

<div class="card">
<button class="start" onclick="startBot()">START ANALYSIS</button>
<button class="stop" onclick="stopBot()">STOP</button>
</div>

<div class="card">
<h3>Market intelligence</h3>
<h2 id="decision">WAITING</h2>
<p id="message">Live market data not connected.</p>
</div>

<div class="card">
<h3>System information</h3>
<p>Trading instrument: Gold / USD</p>
<p>Maximum planned risk per trade: 1%</p>
<p>Trading environment: Simulation</p>
<p>Normal risk target: <span id="normalRisk">1</span>%</p>
<p>Maximum risk per trade: <span id="maxTradeRisk">10</span>%</p>
<p>Maximum combined risk: <span id="maxTotalRisk">10</span>%</p>
<p>Open positions: <span id="openPositions">0</span></p>
<p>Current open risk: $<span id="currentRisk">0</span></p>
<p>Remaining risk allowance: $<span id="remainingRisk">1</span></p>
</div>

<script>
async function refresh() {
    const response = await fetch('/status');
    const data = await response.json();

    document.getElementById('status').innerText = data.status;
    document.getElementById('strategy').value = data.strategy;
    document.getElementById('execution').value = data.execution;
    document.getElementById('risk').innerText = data.risk;
    document.getElementById('decision').innerText = data.decision;

const risk = data.risk_controls;
document.getElementById('normalRisk').innerText = risk.normal_target_percent;
document.getElementById('maxTradeRisk').innerText = risk.max_risk_per_trade_percent;
document.getElementById('maxTotalRisk').innerText = risk.max_total_risk_percent;
document.getElementById('openPositions').innerText = risk.open_positions;
document.getElementById('currentRisk').innerText = risk.current_open_risk;
document.getElementById('remainingRisk').innerText = risk.remaining_risk;
}

async function startBot() {
    await fetch('/start', {method:'POST'});
    refresh();
}

async function stopBot() {
    await fetch('/stop', {method:'POST'});
    refresh();
}

async function saveSettings() {
    await fetch('/settings', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            strategy:document.getElementById('strategy').value,
            execution:document.getElementById('execution').value
        })
    });
    refresh();
}

refresh();
</script>
</body>
</html>
"""

@app.route("/")
def home():
    return render_template_string(PAGE)

@app.route("/status")
def status():
    response = dict(BOT)
    response["risk_controls"] = RISK_MANAGER.status()
    return jsonify(response)

@app.route("/start", methods=["POST"])
def start():
    BOT["status"] = "ANALYSIS RUNNING"
    return jsonify(BOT)

@app.route("/stop", methods=["POST"])
def stop():
    BOT["status"] = "STOPPED"
    return jsonify(BOT)

@app.route("/settings", methods=["POST"])
def settings():
    data = request.get_json() or {}

    if data.get("strategy") in ["SCALPING", "SWING"]:
        BOT["strategy"] = data["strategy"]

    if data.get("execution") in ["MANUAL", "AUTO"]:
        BOT["execution"] = data["execution"]

    return jsonify(BOT)



@app.route("/analyze", methods=["POST"])
def analyze_market():
    data = request.get_json(silent=True) or {}
    candles = data.get("candles")

    if not isinstance(candles, list):
        return jsonify({
            "decision": "WAIT",
            "reason": "Send candle data as a list"
        }), 400

    result = ANALYZER.analyze(candles)
    BOT["decision"] = result["decision"]

    return jsonify(result)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
