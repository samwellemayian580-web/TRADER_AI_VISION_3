import math


class BatchPositionSizer:
    def __init__(
        self,
        risk_percent=1.0,
        max_risk_percent=10.0,
        min_lot=0.01,
        max_lot=100.0,
        lot_step=0.01,
        max_orders=20,
    ):
        self.risk_percent = risk_percent
        self.max_risk_percent = max_risk_percent
        self.min_lot = min_lot
        self.max_lot = max_lot
        self.lot_step = lot_step
        self.max_orders = max_orders

    def calculate(
        self,
        equity,
        entry_price,
        stop_loss,
        contract_size,
        account_currency_per_usd=1.0,
        side="BUY",
        order_count=None,
        available_risk=None,
    ):
        values = [
            equity, entry_price, stop_loss, contract_size,
            account_currency_per_usd, self.risk_percent,
            self.max_risk_percent, self.min_lot,
            self.max_lot, self.lot_step,
        ]

        if any(
            isinstance(v, bool)
            or not isinstance(v, (int, float))
            or not math.isfinite(v)
            or v <= 0
            for v in values
        ):
            return {"approved": False, "reason": "Invalid numeric input"}

        if side not in ("BUY", "SELL"):
            return {"approved": False, "reason": "Invalid trade direction"}

        if (
            self.risk_percent > self.max_risk_percent
            or self.max_risk_percent > 10.0
            or self.min_lot > self.max_lot
            or self.max_orders <= 0
            or not isinstance(self.max_orders, int)
            or isinstance(self.max_orders, bool)
        ):
            return {"approved": False, "reason": "Invalid sizing configuration"}

        if not math.isclose(
            self.min_lot / self.lot_step,
            round(self.min_lot / self.lot_step),
            abs_tol=1e-8,
        ):
            return {"approved": False, "reason": "Minimum lot not aligned to step"}

        if side == "BUY" and stop_loss >= entry_price:
            return {"approved": False, "reason": "BUY stop must be below entry"}

        if side == "SELL" and stop_loss <= entry_price:
            return {"approved": False, "reason": "SELL stop must be above entry"}

        distance = abs(entry_price - stop_loss)

        loss_per_lot = (
            distance * contract_size * account_currency_per_usd
        )

        if not math.isfinite(loss_per_lot) or loss_per_lot <= 0:
            return {"approved": False, "reason": "Invalid loss per lot"}

        normal_budget = equity * self.risk_percent / 100.0
        hard_limit = equity * self.max_risk_percent / 100.0

        if available_risk is None:
            risk_budget = normal_budget
        else:
            if (
                isinstance(available_risk, bool)
                or not isinstance(available_risk, (int, float))
                or not math.isfinite(available_risk)
                or available_risk <= 0
            ):
                return {"approved": False, "reason": "Invalid available risk"}

            risk_budget = min(normal_budget, available_risk)

        risk_budget = min(risk_budget, hard_limit)

        raw_total_lot = risk_budget / loss_per_lot

        max_steps = math.floor(
            self.max_lot / self.lot_step + 1e-10
        )

        # max_lot applies to EACH order, not the whole batch.
        minimum_steps = round(self.min_lot / self.lot_step)

        if order_count is not None:
            if (
                isinstance(order_count, bool)
                or not isinstance(order_count, int)
                or order_count < 1
                or order_count > self.max_orders
            ):
                return {"approved": False, "reason": "Invalid order count"}

            order_capacity = max_steps * order_count
        else:
            order_capacity = max_steps * self.max_orders

        total_steps = min(
            math.floor(raw_total_lot / self.lot_step + 1e-10),
            order_capacity,
        )

        if total_steps < 1:
            return {
                "approved": False,
                "reason": "Risk budget cannot afford minimum lot",
            }

        if order_count is not None:
            if total_steps < order_count * minimum_steps:
                return {
                    "approved": False,
                    "reason": "Insufficient risk budget for requested orders",
                }
            count = order_count
        else:
            if total_steps < minimum_steps:
                return {
                    "approved": False,
                    "reason": "Risk budget cannot afford minimum lot",
                }

            # Use as many separate orders as the budget can support,
            # while respecting the per-order maximum.
            count = min(
                self.max_orders,
                total_steps // minimum_steps,
            )

        if total_steps < count * minimum_steps:
            return {
                "approved": False,
                "reason": "Insufficient risk budget for minimum order sizes",
            }

        base_steps = total_steps // count
        extra_steps = total_steps % count

        orders = []

        for i in range(count):
            steps = base_steps + (1 if i < extra_steps else 0)
            lot = round(steps * self.lot_step, 8)

            if lot < self.min_lot or lot > self.max_lot:
                return {
                    "approved": False,
                    "reason": "Calculated order violates lot limits",
                }

            order_risk = lot * loss_per_lot

            orders.append({
                "order_number": i + 1,
                "lot": lot,
                "estimated_risk": round(order_risk, 4),
            })

        total_lot = sum(order["lot"] for order in orders)
        total_risk = sum(order["estimated_risk"] for order in orders)

        if total_risk > risk_budget + 1e-8:
            return {
                "approved": False,
                "reason": "Batch exceeds available risk",
            }

        return {
            "approved": True,
            "side": side,
            "equity": equity,
            "entry": entry_price,
            "stop_loss": stop_loss,
            "stop_distance": distance,
            "order_count": len(orders),
            "orders": orders,
            "total_lot": round(total_lot, 8),
            "risk_budget": round(risk_budget, 4),
            "total_estimated_risk": round(total_risk, 4),
            "actual_risk_percent": round(total_risk / equity * 100, 4),
            "loss_per_lot": round(loss_per_lot, 4),
            "warning": (
                "Broker tick-value, commission and slippage validation required"
            ),
        }
