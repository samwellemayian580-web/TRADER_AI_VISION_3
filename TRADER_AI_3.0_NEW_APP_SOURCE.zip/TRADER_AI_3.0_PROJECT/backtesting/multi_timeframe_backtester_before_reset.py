from data.historical_adapter import HistoricalDataAdapter
from analysis.multi_timeframe_analyzer import MultiTimeframeAnalyzer
from bisect import bisect_left


class MultiTimeframeBacktester:

    def __init__(
        self,
        starting_balance=100.0,
        risk_percent=1.0,
        reward_ratio=2.0,
        atr_stop_multiple=1.5,
        spread_price=0.0,
        slippage_price=0.0,
        commission_per_trade=0.0,
        window_size=300
    ):
        if starting_balance <= 0:
            raise ValueError("Starting balance must be positive")

        if not 0 < risk_percent <= 10:
            raise ValueError("Risk must be above 0% and at most 10%")

        if reward_ratio <= 0 or atr_stop_multiple <= 0:
            raise ValueError("Reward ratio and ATR multiple must be positive")

        if min(spread_price, slippage_price, commission_per_trade) < 0:
            raise ValueError("Trading costs cannot be negative")

        self.starting_balance = float(starting_balance)
        self.balance = float(starting_balance)
        self.risk_percent = float(risk_percent)
        self.reward_ratio = float(reward_ratio)
        self.atr_stop_multiple = float(atr_stop_multiple)
        self.spread_price = float(spread_price)
        self.slippage_price = float(slippage_price)
        self.commission_per_trade = float(commission_per_trade)
        self.window_size = int(window_size)

        self.adapter = HistoricalDataAdapter()
        self.analyzer = MultiTimeframeAnalyzer()

        self.trades = []
        self.equity_curve = [self.balance]
        self.position = None
        self.pending_signal = None

    def _prepare_snapshot(self, snapshot):
        for timeframe, data in snapshot.items():
            data["candles"] = data["candles"][-self.window_size:]
        return snapshot

    def _enter_position(self, candle, signal, index):
        side = signal["side"]
        atr = signal["atr"]

        distance = atr * self.atr_stop_multiple

        if distance <= 0:
            return False

        risk_cash = self.balance * self.risk_percent / 100.0

        # Approximate entry execution cost.
        entry_cost = self.spread_price / 2 + self.slippage_price

        if side == "BUY":
            entry = candle["open"] + entry_cost
            stop = entry - distance
            target = entry + distance * self.reward_ratio
        else:
            entry = candle["open"] - entry_cost
            stop = entry + distance
            target = entry - distance * self.reward_ratio

        self.position = {
            "side": side,
            "entry": entry,
            "stop": stop,
            "target": target,
            "distance": distance,
            "risk_cash": risk_cash,
            "entry_index": index,
            "signal_time": signal["signal_time"],
            "analysis": signal.get("analysis", {}),
        }

        return True

    def _close_position(self, exit_price, reason, index):
        position = self.position

        exit_cost = self.spread_price / 2 + self.slippage_price

        if position["side"] == "BUY":
            fill = exit_price - exit_cost
            movement = fill - position["entry"]
        else:
            fill = exit_price + exit_cost
            movement = position["entry"] - fill

        r_multiple = movement / position["distance"]

        gross_pnl = position["risk_cash"] * r_multiple
        net_pnl = gross_pnl - self.commission_per_trade

        self.balance += net_pnl

        self.trades.append({
            "side": position["side"],
            "entry": round(position["entry"], 5),
            "exit": round(fill, 5),
            "stop": round(position["stop"], 5),
            "target": round(position["target"], 5),
            "risk_cash": round(position["risk_cash"], 2),
            "gross_pnl": round(gross_pnl, 2),
            "net_pnl": round(net_pnl, 2),
            "r_multiple": round(r_multiple, 3),
            "result": "WIN" if net_pnl > 0 else "LOSS",
            "exit_reason": reason,
            "signal_time": position["signal_time"],
            "exit_index": index,
            "analysis": position.get("analysis", {}),
        })

        self.equity_curve.append(self.balance)
        self.position = None

    def _check_exit(self, candle, index):
        position = self.position

        if position is None:
            return False

        high = candle["high"]
        low = candle["low"]

        if position["side"] == "BUY":
            stop_hit = low <= position["stop"]
            target_hit = high >= position["target"]

            # Conservative rule: assume stop first if both are touched.
            if stop_hit:
                self._close_position(position["stop"], "STOP_LOSS", index)
                return True

            if target_hit:
                self._close_position(position["target"], "TAKE_PROFIT", index)
                return True

        else:
            stop_hit = high >= position["stop"]
            target_hit = low <= position["target"]

            if stop_hit:
                self._close_position(position["stop"], "STOP_LOSS", index)
                return True

            if target_hit:
                self._close_position(position["target"], "TAKE_PROFIT", index)
                return True

        return False

    def _drawdown(self):
        peak = self.starting_balance
        max_drawdown = 0.0

        for equity in self.equity_curve:
            peak = max(peak, equity)

            if peak > 0:
                drawdown = (peak - equity) / peak * 100
                max_drawdown = max(max_drawdown, drawdown)

        return max_drawdown

    def _report(self, strategy, decisions_checked):
        wins = sum(t["net_pnl"] > 0 for t in self.trades)
        losses = sum(t["net_pnl"] <= 0 for t in self.trades)

        gross_profit = sum(
            t["net_pnl"] for t in self.trades if t["net_pnl"] > 0
        )

        gross_loss = abs(sum(
            t["net_pnl"] for t in self.trades if t["net_pnl"] < 0
        ))

        total = len(self.trades)

        profit_factor = (
            gross_profit / gross_loss
            if gross_loss > 0 else None
        )

        return {
            "strategy": strategy,
            "data_source": "Twelve Data session-filtered XAU/USD proxy",
            "starting_balance": round(self.starting_balance, 2),
            "ending_balance": round(self.balance, 2),
            "net_profit": round(self.balance - self.starting_balance, 2),
            "return_percent": round(
                (self.balance / self.starting_balance - 1) * 100, 2
            ),
            "total_trades": total,
            "wins": wins,
            "losses": losses,
            "win_rate_percent": round(wins / total * 100, 2) if total else 0,
            "profit_factor": round(profit_factor, 3) if profit_factor is not None else None,
            "max_drawdown_percent": round(self._drawdown(), 2),
            "decisions_checked": decisions_checked,
            "risk_percent": self.risk_percent,
            "execution_authorized": False,
            "pnl_model": "Normalized R-based estimate; not verified HFM cash PnL",
            "warning": (
                "Spread, slippage and commission are estimates. "
                "Actual HFM contract specifications and execution costs "
                "have not yet been validated."
            )
        }

    def run(self, strategy="SCALPING", max_decisions=500):
        strategy = strategy.upper()

        if strategy not in ("SCALPING", "SWING"):
            raise ValueError("Strategy must be SCALPING or SWING")

        times = self.adapter.get_decision_times()

        required_times = [
            self.adapter.close_times[tf][59]
            for tf in ("M5", "M15", "H1", "H4")
            if len(self.adapter.close_times[tf]) >= 60
        ]

        if len(required_times) != 4:
            raise ValueError("Not enough historical candles")

        earliest_valid_time = max(required_times)
        start_index = bisect_left(times, earliest_valid_time)

        if start_index >= len(times):
            raise ValueError("No valid historical decision times")

        available = len(times) - start_index
        limit = available if max_decisions is None else min(
            available, int(max_decisions)
        )

        if limit <= 0:
            raise ValueError("No decisions available")

        decisions_checked = 0

        for index in range(start_index, start_index + limit):
            decision_time = times[index]
            candle = self.adapter.data["M5"][index]

            # A pending signal enters at the next M5 candle open.
            if self.pending_signal is not None and self.position is None:
                self._enter_position(
                    candle, self.pending_signal, index
                )
                self.pending_signal = None

            # Evaluate the current completed candle for exits.
            closed_this_candle = self._check_exit(candle, index)

            if self.position is not None or closed_this_candle:
                continue

            if index == len(times) - 1:
                continue

            snapshot = self.adapter.get_snapshot(
                decision_time, max_candles=self.window_size
            )

            result = self.analyzer.analyze(
                snapshot,
                strategy=strategy
            )

            decisions_checked += 1

            decision = result.get("decision")
            timeframe_results = result.get("timeframe_results", {})
            m5_result = timeframe_results.get("M5", {})

            diagnostic_fields = (
                "decision", "reason", "trend", "close",
                "ema20", "ema50", "rsi14", "atr14",
                "patterns", "candles_analyzed"
            )

            analysis_snapshot = {
                "strategy": strategy,
                "decision": decision,
                "reason": result.get("reason"),
                "timeframe_trends": result.get("timeframe_trends", {}),
                "timeframes": {
                    tf: {
                        field: timeframe_results.get(tf, {}).get(field)
                        for field in diagnostic_fields
                    }
                    for tf in ("M5", "M15", "H1", "H4")
                }
            }

            atr = m5_result.get("atr14")

            if decision == "BUY_SETUP" and atr:
                self.pending_signal = {
                    "side": "BUY",
                    "atr": float(atr),
                    "signal_time": decision_time.isoformat(),
                    "analysis": analysis_snapshot,
                }

            elif decision == "SELL_SETUP" and atr:
                self.pending_signal = {
                    "side": "SELL",
                    "atr": float(atr),
                    "signal_time": decision_time.isoformat(),
                    "analysis": analysis_snapshot,
                }

        # Close any remaining position at the last available close.
        if self.position is not None:
            last_candle = self.adapter.data["M5"][start_index + limit - 1]
            self._close_position(
                last_candle["close"],
                "END_OF_TEST",
                start_index + limit - 1
            )

        self.pending_signal = None

        return self._report(strategy, decisions_checked)
